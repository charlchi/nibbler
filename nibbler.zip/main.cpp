
#include <iostream>
#include <dlfcn.h>

int main(int argc, char const *argv[])
{

    SnakeGame(argc, argv);
    return 0;
}
